/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import DoiTuong.BaiDang;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author minhc
 */
public class BaiDangDao implements QuanLyDao<BaiDang, String>{
    String insert_sql;
    String update_sql;
    String delete_sql;
    String selectid_sql;
    String selectall_sql;
    Connections con = new Connections();

    @Override
    public void insert(BaiDang entity) {
        insert_sql = "Insert into BaiDang values ('"+entity.getMaTK()+"', N'"+entity.getNoiDung()+"', N'"+entity.getHinhAnh()+"', '"+entity.getNgayDang()+"', N'"+entity.getND_danhGia()+"')";
        
        con.getResult(insert_sql);
        JOptionPane.showMessageDialog(null,"Thêm thành công");
    }

    @Override
    public void update(BaiDang entity) {
        update_sql = "Update BaiDang set NoiDung = N'"+entity.getNoiDung()+"', HinhAnh = "+entity.getHinhAnh()+"', NgayDang = "+entity.getNgayDang()+"', ND_danhGia = "+entity.getND_danhGia()+"' where MaTK = '"+entity.getMaTK()+"'  ";
        con.getResult(update_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
    }

    @Override
    public void delete(BaiDang entity) {
        delete_sql = "Delete BaiDang where MaTK = '"+entity.getMaTK()+"' ";
        con.getResult(delete_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
    }

    @Override
    public BaiDang Select_ID(String id) {
        BaiDang bd = new BaiDang();
        selectid_sql = "Select * from BaiDang = '"+id+"'";
        bd = con.getResult(selectid_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
        return bd;
    }

    @Override
    public List<BaiDang> SelectAll() {
        List<BaiDang> list = new ArrayList<BaiDang>();
        BaiDang bd = new BaiDang();
        bd = con.getBaiDang(SelectAll());
        list.add(bd);
        return list;
    }
}
