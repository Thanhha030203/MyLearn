/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import DoiTuong.DangKy_DichVu;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author minhc
 */
public class DangKy_DichVuDao implements QuanLyDao <DangKy_DichVu, String>{
    String insert_sql;
    String update_sql;
    String delete_sql;
    String selectid_sql;
    String selectall_sql;
    Connections con = new Connections();
    @Override
    public void insert(DangKy_DichVu entity) {
        insert_sql = "Insert into DangKy_DichVu values ('"+entity.getMaDV()+"', '"+entity.getMaTK()+"', '"+entity.getNgayDangKy()+"', '"+entity.getThoiHan()+"', '"+entity.isTrangThaiDangKy()+"')";
        
        con.getResult(insert_sql);
        JOptionPane.showMessageDialog(null,"Thêm thành công");
    }

    @Override
    public void update(DangKy_DichVu entity) {
        update_sql = "Update DichVu set MaTK = '"+entity.getMaTK()+"', NgayDangKy = '"+entity.getNgayDangKy()+"', ThoiHan_Thang = '"+entity.getThoiHan()+"', TrangThaiDangKy = '"+entity.isTrangThaiDangKy()+"'where MaDV = '"+entity.getMaDV()+"'  ";
        con.getResult(update_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
    }

    @Override
    public void delete(DangKy_DichVu entity) {
        delete_sql = "Delete DangKy_DichVu where MaDV = '"+entity.getMaDV()+"' ";
        con.getResult(delete_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
        
    }

    @Override
    public DangKy_DichVu Select_ID(String id) {
        DangKy_DichVu dk = new DangKy_DichVu();
        selectid_sql = "Select * from DichVu = '"+id+"'";
        dk = con.getResult(selectid_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
        return dk;
    }

    @Override
    public List<DangKy_DichVu> SelectAll() {
        List<DangKy_DichVu> list = new ArrayList<DangKy_DichVu>();
        DangKy_DichVu dk = new DangKy_DichVu();
        dk = con.getDangKy_DichVu(SelectAll());
        list.add(dk);
        return list;
    }



    
}
