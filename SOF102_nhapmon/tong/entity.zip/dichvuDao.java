/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import DoiTuong.DichVu;
import java.sql.JDBCType;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author minhc
 */
public class dichvuDao implements QuanLyDao<DichVu,String>{
    String insert_sql;
    String update_sql;
    String delete_sql;
    String selectid_sql;
    String selectall_sql;
    Connections con = new Connections();
    @Override
    public void insert(DichVu entity) {
        insert_sql = "Insert into dichvu values ('"+entity.getMaDV()+"', '"+entity.getTenDV()+"', N'"+entity.getPhiDV()+"', '"+entity.getNgayPhatHanh()+"', '"+entity.getHanKetThuc()+"')";
        
        con.getResult(insert_sql);
        JOptionPane.showMessageDialog(null,"Thêm thành công");
    }

    @Override
    public void update(DichVu entity) {
        update_sql = "Update DichVu set TenDV = N'"+entity.getTenDV()+"', PhiDV = "+entity.getPhiDV()+"', NgayPhatHanh = "+entity.getNgayPhatHanh()+"', HanKetThuc = "+entity.getHanKetThuc()+"' where MaDV = '"+entity.getMaDV()+"'  ";
        con.getResult(update_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
    }

    @Override
    public void delete(DichVu entity) {
        delete_sql = "Delete DichVu where MaDV = '"+entity.getMaDV()+"' ";
        con.getResult(delete_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
        
    }

    @Override
    public DichVu Select_ID(String id) {
        DichVu dv = new DichVu();
        selectid_sql = "Select * from DichVu = '"+id+"'";
        dv = con.getResult(selectid_sql);
        JOptionPane.showMessageDialog(null,"Cập nhật thành công");
        return dv;
    }

    @Override
    public List<DichVu> SelectAll() {
        List<DichVu> list = new ArrayList<DichVu>();
        DichVu dv = new DichVu();
        dv = con.getDichVu(SelectAll());
        list.add(dv);
        return list;
    }
    
}
